import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.http.HttpRequest.BodyPublishers;
import java.net.http.HttpResponse.BodyHandlers;

public class Client {
    private static final String BASE_URL = "https://azf-products-jjj.azurewebsites.net/products";
    private HttpClient client;

    public Client() {
        this.client = HttpClient.newHttpClient();
    }

    public String getProducts() {
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL))
                    .header("Content-Type", "application/json").header("api-key", "ApiKeyTestJJJAdminsIlimited")
                    .GET()
                    .build();
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            return response.body();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    public String addProduct(String name, String description, int stock, double price) {
        String json = String.format("{\"name\":\"%s\",\"description\":\"%s\",\"stock\":%d,\"price\":%.2f}",
                                    name, description, stock, price);
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL))
                    .header("Content-Type", "application/json").header("api-key", "ApiKeyTestJJJAdminsIlimited")
                    .POST(BodyPublishers.ofString(json))
                    .build();
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            return response.body();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }

    public String updateProductStock(int productId, int newStock) {
        String json = String.format("{\"stock\":%d}", newStock);
        try {
            HttpRequest request = HttpRequest.newBuilder()
                    .uri(URI.create(BASE_URL + "/" + productId))
                    .header("Content-Type", "application/json").header("api-key", "ApiKeyTestJJJAdminsIlimited")
                    .method("PATCH", BodyPublishers.ofString(json))
                    .build();
            HttpResponse<String> response = client.send(request, BodyHandlers.ofString());
            return response.body();
        } catch (Exception e) {
            return "Error: " + e.getMessage();
        }
    }
}