import javax.swing.*;
import java.awt.*;
import org.json.*;

public class UI extends JFrame {
    private JTextField nameField, descriptionField, stockField, priceField, productIdField, updateStockField;
    private JList<String> responseList;
    private DefaultListModel<String> listModel;
    private JButton getButton, addButton, updateButton;
    private Client client = new Client();

    public UI() {
        setTitle("Product Manager");
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        initializeUI();
        getProducts(); // Auto-fetch products on start
    }

    private void initializeUI() {
        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));

        listModel = new DefaultListModel<>();
        responseList = new JList<>(listModel);
        JScrollPane scrollPane = new JScrollPane(responseList);
        scrollPane.setPreferredSize(new Dimension(500, 200));
        panel.add(scrollPane);

        getButton = new JButton("Refresh Products");
        getButton.addActionListener(e -> getProducts());
        panel.add(getButton);

        panel.add(new JLabel("Add Product:"));
        nameField = new JTextField(20);
        descriptionField = new JTextField(20);
        stockField = new JTextField(20);
        priceField = new JTextField(20);
        addButton = new JButton("Add Product");
        addButton.addActionListener(e -> addProduct());
        panel.add(new JLabel("Name:"));
        panel.add(nameField);
        panel.add(new JLabel("Description:"));
        panel.add(descriptionField);
        panel.add(new JLabel("Stock:"));
        panel.add(stockField);
        panel.add(new JLabel("Price:"));
        panel.add(priceField);
        panel.add(addButton);

        panel.add(new JLabel("Update Product Stock:"));
        productIdField = new JTextField(20);
        updateStockField = new JTextField(20);
        updateButton = new JButton("Update Stock");
        updateButton.addActionListener(e -> updateProductStock());
        panel.add(new JLabel("Product ID:"));
        panel.add(productIdField);
        panel.add(new JLabel("New Stock:"));
        panel.add(updateStockField);
        panel.add(updateButton);

        add(panel);
    }

    private void getProducts() {
        new Thread(() -> {
            String result = client.getProducts();
            SwingUtilities.invokeLater(() -> updateProductList(result));
        }).start();
    }

    private void updateProductList(String jsonData) {
        listModel.clear();
        try {
            JSONArray array = new JSONArray(jsonData);
            for (int i = 0; i < array.length(); i++) {
                JSONObject obj = array.getJSONObject(i);
                String product = "ID: " + obj.getInt("id") + ", Name: " + obj.getString("name") +
                                 ", Description: " + obj.getString("description") +
                                 ", Price: $" + obj.getDouble("price") +
                                 ", Stock: " + obj.getInt("stock");
                listModel.addElement(product);
            }
        } catch (JSONException e) {
            e.printStackTrace();
            listModel.addElement("Error parsing JSON data.");
        }
    }

    private void addProduct() {
        new Thread(() -> {
            String result = client.addProduct(nameField.getText(), descriptionField.getText(),
                    Integer.parseInt(stockField.getText()), Double.parseDouble(priceField.getText()));
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, result);
                getProducts(); // Refresh list after adding
            });
        }).start();
    }

    private void updateProductStock() {
        new Thread(() -> {
            int productId = Integer.parseInt(productIdField.getText());
            int newStock = Integer.parseInt(updateStockField.getText());
            String result = client.updateProductStock(productId, newStock);
            SwingUtilities.invokeLater(() -> {
                JOptionPane.showMessageDialog(this, result);
                getProducts(); // Refresh list after updating
            });
        }).start();
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() -> new UI().setVisible(true));
    }
}
